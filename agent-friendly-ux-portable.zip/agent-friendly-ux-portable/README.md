# Agent-Friendly UX — Portable AI Agent Skill

A portable AI agent skill that ensures websites are optimized for AI agent navigation and interaction. Compatible with **standalone Claude (claude.ai)**, **Replit Agent**, and any other AI environment that supports the Agent Skills format. Based on Google's [Build agent-friendly websites](https://web.dev/articles/ai-agent-site-ux) guide.

**Author:** Julia Logan, Head of SEO at [AICT Media](https://aictmedia.com)

## What It Does

AI agents are becoming a new class of website visitor. They navigate on behalf of humans using screenshots, raw HTML, and the accessibility tree — not a monitor. This skill ensures every site you build sends clean signals across all three channels.

### Two Modes

**1. Build Mode** — Automatically enforces agent-friendly practices while creating websites:

- Semantic HTML for all interactive elements (`<button>`, `<a>`, not styled `<div>`s)
- Proper form labeling (every input linked to a `<label>` or `aria-label`)
- Stable, consistent layouts so agents can reliably find actions
- No ghost elements or transparent overlays hiding interactive content
- Appropriately sized click targets (minimum 24x24px, 44x44px recommended)
- Correct heading hierarchy and semantic page structure
- ARIA attributes for dynamic states (expanded, loading, disabled)
- Visible UI affordances for all actions (no hover-only or gesture-only interactions)
- `cursor: pointer` on custom interactive elements

**2. Audit Mode** — Analyzes any existing website and produces a scored report:

- Visual analysis from screenshots (layout stability, element sizing, ghost elements)
- Structural analysis from HTML (semantic markup, form labels, ARIA, heading hierarchy)
- Findings organized by severity: Critical, Warning, Suggestion
- Specific fix recommendations for every issue found
- Score out of 10

## Why a Portable Version?

This skill is platform-agnostic — it does not reference any specific tool names, environment paths, or platform features. It uses generic language like "use available screenshot and web-fetch tools" instead of naming Replit's `screenshot` or `webFetch` callbacks. This makes it drop-in compatible with:

- **Claude.ai** (standalone Claude with Agent Skills)
- **Claude Desktop**
- **Replit Agent**
- **Custom Anthropic API integrations**
- **Any other agent platform supporting the SKILL.md format**

If you're using Replit specifically and want a version with Replit-tool-aware audit instructions, see the `agent-friendly-ux` (non-portable) version.

## Installation

### For Claude.ai / Claude Desktop

1. Locate your skills directory (Claude.ai supports user-uploaded skills via the Skills feature)
2. Upload or copy the `SKILL.md` file as a new skill
3. The skill will be automatically referenced when relevant

### For Replit Agent

1. Copy `SKILL.md` into your Replit project at `.agents/skills/agent-friendly-ux/SKILL.md`
2. The skill is automatically available

### For Other Platforms

Place `SKILL.md` in your platform's skill directory following its conventions. The frontmatter format is the standard Anthropic Agent Skills format:

```yaml
---
name: skill-name
description: What the skill does and when to use it
---
```

## Usage

### When Building Sites

The skill activates automatically whenever you ask the agent to create or modify web pages, components, forms, buttons, navigation, or layouts. No special prompt needed — just build as usual and the agent will follow the guidelines.

### When Auditing Sites

Ask the agent to review any website for AI agent friendliness:

- "Check this site for AI agent friendliness: https://example.com"
- "Audit my app for agent-friendly UX"
- "Is this website optimized for AI agents?"

The agent will use whatever tools are available in its environment (screenshots, web fetching, or asking you to paste HTML) and produce a structured report with a score and actionable recommendations.

## The 10 Rules

| # | Rule | Why It Matters |
|---|------|---------------|
| 1 | Use semantic HTML for interactive elements | Agents recognize `<button>` and `<a>` as interactive |
| 2 | Ensure stable, consistent layouts | Screenshot-based agents get confused by shifting elements |
| 3 | Eliminate ghost elements and transparent overlays | Agents discard elements that appear covered |
| 4 | Label all form inputs | Agents need labels to understand field purposes |
| 5 | Ensure interactive elements are large enough | Elements under 8 sq px get filtered out by visual analysis |
| 6 | Use `cursor: pointer` for clickable elements | Strong signal for actionability in visual analysis |
| 7 | Make all actions visible in the interface | Hidden actions are invisible to agents |
| 8 | Write clean, structured HTML | Agents parse the DOM to understand element relationships |
| 9 | Provide meaningful ARIA when needed | Helps agents understand dynamic element states |
| 10 | Ensure state changes are reflected in the DOM | Agents read attributes to understand current state |

## Quick Checklist

- [ ] All clickable elements use `<button>` or `<a>` (or have `role` + `tabindex`)
- [ ] All form inputs have associated `<label>` elements or `aria-label`
- [ ] Interactive elements have visible area > 8 sq px (prefer 44x44px)
- [ ] No transparent overlays covering interactive elements
- [ ] Layout is stable — key actions don't shift position across similar pages
- [ ] Page uses semantic HTML structure (`nav`, `main`, `section`, `article`, `footer`)
- [ ] Dynamic states reflected via DOM attributes (`disabled`, `aria-expanded`, `aria-busy`)
- [ ] All user actions have visible UI affordances
- [ ] Custom interactive elements use `cursor: pointer`
- [ ] Heading hierarchy is correct and sequential

## References

- [Build agent-friendly websites — web.dev](https://web.dev/articles/ai-agent-site-ux)
- [The Accessibility Tree — web.dev](https://web.dev/articles/the-accessibility-tree)
- [WebMCP Proposal — Chrome Developer Blog](https://developer.chrome.com/blog/webmcp-epp)
- [Anthropic Agent Skills documentation](https://docs.anthropic.com)

## License

This skill is freely available for use and modification.
